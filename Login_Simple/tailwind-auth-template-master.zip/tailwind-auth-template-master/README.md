# Tailwind Login & Register Templates

These are login and register templates buit with [Tailwind](https://tailwindcss.com/). They are inspired by [this dribble shot by Roman Bystrytskyi](https://dribbble.com/shots/3829284-Dipnet-login-page).

View the login demo [here](https://tailwind-auth-demo.dgrzyb.me/login.html) and the register demo [here](https://tailwind-auth-demo.dgrzyb.me/register.html) 😎

<img src="screenshot.png">